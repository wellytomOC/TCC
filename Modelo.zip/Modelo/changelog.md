# Histórico de versões

v1.0.1 [2024-05-03]: ajuste de normas na paginação dos elementos pré-textuais; no espaçamento dos títulos de seções textuais; *workaround* de *bug* da classe `memoir` na re-utilização do commando `\appendix`; otimização geral da classe.

v1.0.0 [2024-04-27]: publicação inicial da classe e modelo.
