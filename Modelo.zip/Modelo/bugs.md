# Known bugs

A NBR 14724:2011 exige que *títulos que ocupem mais de uma linha devem ser, a partir da segunda linha, alinhados abaixo da primeira letra da primeira palavra do título*. Não há uma forma de implementar isso usando a classe memoir para os títulos dos capítulos, embora esse problema não seja aparente com os títulos padrão do modelo.
